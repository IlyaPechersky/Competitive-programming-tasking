#include "testlib.h"

int main(int argc, char** argv) {
    registerGen(argc, argv, 1);

    int maxN = atoi(argv[1]);
    int p = atoi(argv[2]);
    
	int first = atoi(argv[3]);
	int last = atoi(argv[4]);

	for (int test = first; test <= last; ++test) {
		startTest(test);

		int n = rnd.next(1, maxN);

		std::cout << n << ' ' << p << std::endl;
		for (int i = 0; i < n; ++i) {
			std::cout << rnd.next(1, n);
			if (i != n - 1) std::cout << ' '; 
		}
		std::cout << std::endl;
	}
    return 0;
}