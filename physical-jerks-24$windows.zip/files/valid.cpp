#include "testlib.h"
#include <set>

using namespace std;

int group[] = {10, 8, (int)1e5, (int)1e5};
int t[(int)1e5 + 5];

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int g = atoi(validator.group().c_str());
    if (validator.group() == "") g = 0;
    int n = inf.readInt(1, group[g], "n");
    inf.readSpace();
    int p = inf.readInt(1, 2, "p");
    if (g == 2) ensuref(p == 1, "the variable must be equal to one");
    if (g == 3) ensuref(p == 2, "the variable must be equal to two");
    inf.readEoln();
    for (int i = 0; i < n; i++) {
        t[i] = inf.readInt(1, n, "t_i");
        if (i != n - 1) inf.readSpace();
    }
    inf.readEoln();
    inf.readEof();
}