#include "./testlib.h"
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <set>
using namespace std;
typedef long long ll;

const ll INF = 1e5;
const int MAXN = (int)1e5 + 10;
int n, p, t[MAXN];
set<int> check;

ll getAnswer(InStream &in)
{
    int x;
    check.clear();
    ll res = 0;
    for (int i = 0; i < n; i++) {
        x = in.readInt(1, n);
        check.insert(x);
        if (p == 1) {
            res +=  abs(x - t[i]);
        } else {
            res += (ll)(x - t[i]) * (ll)(x - t[i]);
        }
    }
    return res;
}

int main(int argc, char * argv[])
{
    registerTestlibCmd(argc, argv);

    n = inf.readInt();
    p = inf.readInt();
    for (int i = 0; i < n; i++) {
        t[i] = inf.readInt();
    }

    ll jury = getAnswer(ans);
    
    if (check.size() != n) {
        quitf(_fail, "Jury has an incorrect answer");
    }
    
    ll part = getAnswer(ouf);


    if (check.size() != n) {
        quitf(_wa, "Participant has a mistake");
    }
    
    
    if (jury < part) {
        quitf(_fail, "Participant has better answer (%lld) than jury (%lld)", part, jury);
    }
    if (jury > part) {
        quitf(_wa, "Jury has better answer (%lld) than participant (%lld)", jury, part);
    }
    quitf(_ok, "OK valid solution");

    return 0;
}