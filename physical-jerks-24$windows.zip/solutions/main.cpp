#include <bits/stdc++.h>

typedef long long ll;

using namespace std;

int main(int argc, char* argv[]) {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int p, n, time;
    cin >> n >> p;
    vector<pair<ll, int>> t(n);
    vector<int> ans(n);
    for (int i = 0; i < n; i++) {
        cin >> time;
        t[i] = {time, i};
    }

    sort(t.begin(), t.end());
    for (int i = 0; i < n; ++i) {
        ans[t[i].second] = n - i;
    }

    for (int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }
}