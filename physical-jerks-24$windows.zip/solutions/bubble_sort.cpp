#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

vector<pair<int, int>> bubble_sort(pair<int, int> arr[], int n) {
    for (int i = 1; i < n; ++i) {
        for (int r = 0; r < n - i; r++) {
            if (arr[r] < arr[r + 1]) {
                pair<int, int> temp = arr[r];
                arr[r] = arr[r + 1];
                arr[r + 1] = temp;
            }
        }
    }
    vector<pair<int, int>> res;
    for (int i = 0; i < n; i++) {
        res.push_back(arr[i]);
    }
    return res;
}

int main(int argc, char *argv[]) {
    int n, p, a;
    cin >> n >> p;
    pair<int, int> arr[n];
    for (int i = 0; i < n; i++) {
        cin >> a;
        arr[i] = {a, i};
    }

    vector<pair<int, int>> sorted = bubble_sort(arr, n);
    vector<int> ans(n);
    for (int i = 0; i < n; i++) {
        ans[sorted[i].second] = i + 1;
    }

    for (int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }
    return 0;
}