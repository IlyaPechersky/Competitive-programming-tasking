n, p = list(map(int, input().split()))
t = []
ans = [0] * n
s = input().split()
for i in range(n):
    t.append([int(s[i]), i])
t.sort(key=lambda x: x[0])
for i in range(n):
    ans[t[i][1]] = n - i
for i in ans:
    print(i, end=" ")