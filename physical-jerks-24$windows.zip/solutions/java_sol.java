import java.io.*;
import java.util.*;

import static java.lang.Math.*;

public class java_sol {

    static class Pair implements Comparable<Pair> {
        int x, i;

        public Pair(int x, int i) {
            this.x = x;
            this.i = i;
        }

        @Override
        public int compareTo(Pair o) {
            return this.x - o.x;
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int p = scan.nextInt();
        Pair[] a = new Pair[n];
        for (int i = 0; i < n; i++) {
            int x = scan.nextInt();
            a[i] = new Pair(x, i);
        }
        Arrays.sort(a);
        int[] ans = new int[n];
        for (int i = 0; i < n; i++) {
            ans[a[i].i] = n - i;
        }
        for (int i = 0; i < n; i++) {
            System.out.print(ans[i] + " ");
        }
    }
}
