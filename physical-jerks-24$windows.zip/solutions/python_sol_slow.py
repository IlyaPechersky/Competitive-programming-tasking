import itertools
n, p = list(map(int, input().split()))
t = []
ans = [0] * n
s = input().split()
for i in range(n):
    t.append([int(s[i]), i])
perm = []
for i in range(n):
    perm.append(i + 1)
ans = []
max = 0
for pe in itertools.permutations(perm):
    sum = 0
    for i in range(len(pe)):
        if (p == 1):
            sum += abs(list(pe)[i] - t[i][0])
        else:
            sum += (list(pe)[i] - t[i][0]) ** 2
    if sum >= max:
        max = sum
        ans = list(pe)
for i in ans:
    print(i, end=" ")
