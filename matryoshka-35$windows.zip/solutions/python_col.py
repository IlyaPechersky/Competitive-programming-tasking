def main():
    from math import sqrt
    maxn = int(1e6) + 1
    m = int(input())
    ans = 2
    for a in range(1, maxn):
        if m % a > 0: continue
        n = m // a
        uk1 = int(sqrt(n))
        if uk1 * uk1 + uk1 == n:
            ans = 3
            break
    for x in range(2, maxn):
        if m % (x * (x + 1)) == 0:
            ans = 3
            break
    for x in range(2, maxn):
        tmp = x + 1
        for k in range(2, 30):
            if m // (tmp * x) < x + 1: break
            else:
                tmp *= (x + 1)
                if m % (tmp * x) == 0:
                    ans = max(ans, k + 2)

    print(ans)


if __name__ == '__main__':
    main()
