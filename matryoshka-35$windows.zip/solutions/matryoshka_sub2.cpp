#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <iostream>
#include <vector>
#include <cstdio>
#include <string>
#include <set>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <bitset>
#include <climits>
#include <queue>
using namespace std;
typedef  long long  li;
typedef long double ld;
const li MAX = 100042;
li m;
int main() {
	//	freopen("input.txt", "r", stdin);
	//	freopen("output.txt", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin >> m;
	li ans = 2;
	for (int i = 3; i <= m + 1; i++) {
		li e = 0;
		li tmp = m;
		while (tmp % i == 0) {
			tmp /= i;
			e++;
		}
		if (tmp % (i - 1) == 0)
		ans = max(ans, e + 2);
	}
	cout << ans;
	//system("pause");
	return 0;
}