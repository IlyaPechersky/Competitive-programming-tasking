#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <queue>
#include <bitset>
using namespace std;

#ifdef LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42
#endif

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef pair<ll, ll> pll;
typedef long double ld;
#define mp make_pair
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int ans = 2;
int sz;
ll p[60][2];
ll m;

void brute(int pos, ll x) {
	if (pos == sz) {
		if (x == 1) return;
		int k = 2;
		ll z = m / x;
		while(z % (x + 1) == 0) {
			z /= x + 1;
			k++;
		}
		ans = max(ans, k);
		return;
	}
	for (int i = 0; i <= p[pos][1]; i++) {
		brute(pos + 1, x);
		x *= p[pos][0];
	}
}

int main()
{
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);

	scanf("%lld", &m);
	ll z = m;
	for (ll x = 2; x * x <= z; x++) {
		if (z % x) continue;
		p[sz][0] = x;
		p[sz][1] = 0;
		while(z % x == 0) {
			p[sz][1]++;
			z /= x;
		}
		sz++;
	}
	if (z != 1) {
		p[sz][0] = z;
		p[sz][1] = 1;
		sz++;
	}
	brute(0, 1);
	printf("%d\n", ans);

	return 0;
}
