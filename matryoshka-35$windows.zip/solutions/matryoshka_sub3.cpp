	
#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <iostream>
#include <vector>
#include <cstdio>
#include <string>
#include <set>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <bitset>
#include <climits>
#include <queue>
using namespace std;
typedef  long long  li;
typedef long double ld;
const li MAX = 100042;
li m;
int main() {
	//	freopen("input.txt", "r", stdin);
	//	freopen("output.txt", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin >> m;
	li ans = 2;
	vector <li> tmp;
	for (li i = 2; i * i <= m; i++) {
		if (m % i == 0) tmp.push_back(i);
		if (m % i == 0 && i * i != m) tmp.push_back(m / i);
	}
	sort(tmp.begin(), tmp.end());
	tmp.push_back(m);
	for (li i = 0; i < tmp.size(); i++) {
		if (tmp[i] == 2) continue;
		if (m % (tmp[i] - 1) != 0) continue;
		else {
			li c = 0;
			li kek = m;
			while (kek % tmp[i] == 0) {
				c++;
				kek /= tmp[i];
			}
			ans = max(ans, c + 2);
		}
	}
	cout << ans;
	//	system("pause");
	return 0;
}