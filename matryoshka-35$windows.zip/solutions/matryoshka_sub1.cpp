#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <iostream>
#include <vector>
#include <cstdio>
#include <string>
#include <set>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <bitset>
#include <climits>
#include <queue>
using namespace std;
typedef  long long  li;
typedef long double ld;
const li MAX = 100042;
int main() {
	//	freopen("input.txt", "r", stdin);
	//	freopen("output.txt", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	li m;
	cin >> m;
	li ans = 0;
	for (li x = 3; x <= m + 1; x++) {
		for (li curmin = 1; curmin <= m; curmin++) {
			li tmpcurmin = curmin * (x - 1), sz = 2;
			for (; tmpcurmin * x <= m; ) {
				sz += 1;
				tmpcurmin *= x;
			}
			if (tmpcurmin == m) {
				if (sz > ans) {
					ans = sz;
				}
			}
		}
	}
	if (ans == 0) {
		ans = 2;
	}
	cout << ans;
	return 0;
}