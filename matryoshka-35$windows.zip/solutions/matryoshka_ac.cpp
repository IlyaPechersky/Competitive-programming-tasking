#pragma comment(linker, "/stack:200000000")
#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#include <iostream>
#include <vector>
#include <cstdio>
#include <string>
#include <set>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <bitset>
#include <climits>
#include <queue>
using namespace std;
typedef  long long  li;
typedef long double ld;
const li MAX = 100042;
li m;
int main() {
	//	freopen("input.txt", "r", stdin);
	//	freopen("output.txt", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	li ans = 2;
	cin >> m;
	for (li a = 1; a <= 1000000; a++) {
		// m / a = x^2 + x	    
		if (m % a) continue;
		li n = m / a;
		li uk1 = 2, uk2 = 2500000000;
		while(uk2 - uk1 > 1){
		    li mid = (uk2 + uk1) / 2;
		    if (li(mid * mid + mid) <= n) uk1 = mid;
		    else uk2 = mid;
		}
		if (uk1 * uk1 + uk1 == n) ans = 3;
	}
	for (li x = 2; x <= 1000000; x++) {
		if (m % (x * (x + 1)) == 0) ans = 3;
	}
	for (li x = 2; x <= 1000000; x++) {
		li tmp = x + 1;
		for (li k = 2; k <= 70; k++) {
			if (m / (tmp * x) < x + 1) break;
			else {
				tmp *= (x + 1);
				if (m % (tmp * x) == 0) ans = max(ans, k + 2);
			}
		}
	}
	cout << ans;
//	system("pause");
	return 0;
}