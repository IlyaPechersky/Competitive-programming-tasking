#include "testlib.h"

int main(int argc, char** argv) {
	registerValidation(argc, argv);

	long long MAX;
	if (validator.group() == "1") {
	    MAX = (long long)1e3;
	} 
	else if (validator.group() == "2") {
	     MAX = (long long)1e6;
	} 
	else if (validator.group() == "3") {
	     MAX = (long long)1e12;
	} 
	else if (validator.group() == "4") {
	     MAX = (long long)1e9 * (long long)1e9;
	}
    long long m = inf.readLong(2, MAX, "m");
	inf.readEoln();
	inf.readEof();
	return 0;
}