#include "jngen.h"

int main(int argc, char** argv) {
	registerGen(argc, argv, 1);

	int n = 100'000;

	setMod().printN().printM().add1();

	auto t = Tree::random(n).shuffled();
	std::cout << t << std::endl;

	return 0;
}