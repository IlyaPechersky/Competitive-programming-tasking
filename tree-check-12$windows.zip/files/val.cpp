#include "testlib.h"
#include <unordered_set>

const int N = 100100;

std::unordered_set<int> g[N];
int used[N];
bool cycle = false;

void dfs(int v, int p = -1) {
	used[v] = 1;

	for (auto to : g[v]) {
		if (to == p) {
			continue;
		}

		if (used[to] == 0) {
			dfs(to, v);
		} else if (used[to] == 1) {
			cycle = true;
		}
	}

	used[v] = 2;
}

int main(int argc, char** argv) {
	registerValidation(argc, argv);

	int n = inf.readInt(1, 100'000, "n");
	inf.readSpace();
	int m = inf.readInt(0, 100'000, "m");
	inf.readEoln();

	for (int i = 0; i < m; ++i) {
		int from = inf.readInt(1, n, "a_i");
		inf.readSpace();
		int to = inf.readInt(1, n, "b_i");
		inf.readEoln();

		ensuref(from != to, "Loops aren't allowed");
		ensuref(g[from - 1].find(to - 1) == g[from - 1].end(), "Multi-edges aren't allowed");

		g[from - 1].insert(to - 1);
		g[to - 1].insert(from - 1);
	}

	inf.readEof();

	dfs(0);

	for (int i = 0; i < n; ++i) {
		ensuref(used[i] != 0, "Graph must be connected");
	}

	return 0;
}