#include "jngen.h"

void generate(int maxN, int maxM, int test) {
	int isTree = test % 2;
	int n = rnd.next(std::max(1, maxN / 2), maxN);
	int m = rnd.next((long long)(n - 1), std::min(1ll * n * (n - 1) / 2, (long long)maxM));

	if (isTree == 0) {
		int type = (test / 2) % 3;

		if (type == 0) {
			auto g = Graph::random(n, m).connected(true).allowMulti(false).allowLoops(false).directed(false).g().shuffled();
			std::cout << g << std::endl;
		} else if (type == 1 && 1ll * n * (n - 1) / 2 <= maxM) {
			auto g = Graph::complete(n).connected(true).allowMulti(false).allowLoops(false).directed(false).g().shuffled();
			std::cout << g << std::endl;
		} else {
			auto g = Graph::cycle(n).connected(true).allowMulti(false).allowLoops(false).directed(false).g().shuffled();
			std::cout << g << std::endl;
		}
	} else {
		int type = ((test - 1) / 2) % 4;

		if (type == 0) {
			auto t = Tree::random(n).shuffled();
			std::cout << t << std::endl;
		} else if (type == 1) {
			auto t = Tree::bamboo(n).shuffled();
			std::cout << t << std::endl;
		} else if (type == 2) {
			auto t = Tree::star(n).shuffled();
			std::cout << t << std::endl;
		} else if (type == 3) {
			auto t = Tree::binary(n).shuffled();
			std::cout << t << std::endl;
		}
	}
}

int main(int argc, char** argv) {
	registerGen(argc, argv, 1);

	int maxN = atoi(argv[1]);
	int maxM = atoi(argv[2]);
	int first = atoi(argv[3]);
	int last = atoi(argv[4]);

    setMod().printN().printM().add1();

	for (int test = first; test <= last; ++test) {
		startTest(test);
		generate(maxN, maxM, test);
	}

	return 0;
}