#include "jngen.h"

int main(int argc, char** argv) {
	registerGen(argc, argv, 1);

	int n = 100'000;
	int m = 100'000;

	setMod().printN().printM().add1();

	auto g = Graph::random(n, m).connected(true).allowMulti(false).allowLoops(false).directed(false).g().shuffled();
	std::cout << g << std::endl;

	return 0;
}