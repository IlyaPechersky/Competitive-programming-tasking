// #pragma comment(linker, "/stack:200000000")
// #pragma GCC optimize("Ofast,no-stack-protector")
// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,tune=native")
// #pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>

#define debug(x) std::cerr << (#x) << ":\t" << (x) << std::endl;
#define fastIO std::ios_base::sync_with_stdio(false);std::cin.tie(0);std::cout.tie(0);
#define NAME "Problem Name"

typedef long long ll;
typedef long double ld;

std::mt19937 rnd(std::chrono::high_resolution_clock::now().time_since_epoch().count());

const double PI = atan2(0., -1.);
const int INF = 0x3f3f3f3f;

int main(void) {
	// #ifdef ONLINE_JUDGE
	// 	freopen(NAME".in", "r", stdin);
	// 	freopen(NAME".out", "w", stdout);
	// #endif

	int n, m;
	scanf("%d%d", &n, &m);

	if (m == n - 1) {
		printf("YES\n");
	} else {
		printf("NO\n");
	}

	return 0;
}
