#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <queue>
#include <bitset>
using namespace std;

#ifdef LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42
#endif

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef pair<ll, ll> pll;
typedef long double ld;
#define mp make_pair
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int N = 128;
const int M = 1024;
pii q[N * M + 3];
int topQ;
int par[N + 3][M + 3];
int s, t;
int ans[M * N + 3];
int ansSz;

int main()
{
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);

	scanf("%d%d", &s, &t);
	if (s >= N || t >= N) {
		printf("2\n%d %d\n", s, t);
		return 0;
	}
	for (int v = 0; v < N; v++)
		for (int x = 0; x < M; x++)
			par[v][x] = -1;
	par[s][0] = -2;
	q[topQ++] = mp(s, 0);
	for (int i = 0; i < topQ; i++) {
		int v = q[i].first, x = q[i].second;
		for (int u = 1; u < N; u++) {
			if (v * u >= M) break;
			int y = x ^ (v * u);
			if (par[u][y] == -1) {
				par[u][y] = v;
				q[topQ++] = mp(u, y);
			}
		}
	}
	for (int i = 0; i < M; i++) {
		//cerr << i << endl;
		if (par[t][i] != -1) {
			int v = t, x = i;
			ans[ansSz++] = v;
			while(v != s || x != 0) {
				int u = par[v][x];
				x ^= v * u;
				v = u;
				ans[ansSz++] = v;
			}
			reverse(ans, ans + ansSz);
			printf("%d\n", ansSz);
			for (int j = 0; j < ansSz; j++)
				printf("%d ", ans[j]);
			printf("\n");
			return 0;
		}
	}
	throw;
	return 0;
}
