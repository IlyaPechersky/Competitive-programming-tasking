#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <queue>
#include <bitset>
using namespace std;

#ifdef LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42
#endif

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;
typedef pair<ll, ll> pll;
typedef long double ld;
#define mp make_pair
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int N = 300;
int cur[N];
int curSz;
ll best;
int ans[N];
int ansSz;
ll m;
int s, t;

void solve() {
	curSz = 0;
	cur[curSz++] = s;
	ll curXor = 0;
	while(curSz + 5 < N) {
		ll zz = curXor ^ ((ll)cur[curSz - 1] * t);
		if (zz < best) {
			best = zz;
			ansSz = curSz;
			for (int i = 0; i < ansSz; i++)
				ans[i] = cur[i];
			ans[ansSz++] = t;
		}
		cur[curSz] = 1 + rng() % m;
		curXor ^= (ll)cur[curSz] * cur[curSz - 1];
		curSz++;
	}
}

int main()
{
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);

	scanf("%d%d", &s, &t);
	best = (ll)s * t;
	ans[ansSz++] = s;
	ans[ansSz++] = t;

	m = 1;
	while(m <= s || m <= t) m <<= 1;
	m--;

	while(best > 0 && (double)clock() / CLOCKS_PER_SEC < 1.8) {
		solve();
	}

	printf("%d\n", ansSz);
	for (int i = 0; i < ansSz; i++)
		printf("%d ", ans[i]);
	printf("\n");

	return 0;
}
