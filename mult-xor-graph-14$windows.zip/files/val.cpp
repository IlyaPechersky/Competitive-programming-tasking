#include "./testlib.h"
#include <iostream>
#include <algorithm>
#include <set>
#include <vector>
using namespace std;

typedef long long ll;

int C[] = {7, 7, 7, 7, (1 << 28) - 1};

int main(int argc, char* argv[]){
    registerValidation(argc, argv);

    int g = atoi(validator.group().c_str());
    if (validator.group() == "") g = 4;
    int s = inf.readInt(1, C[g], "s");
    inf.readSpace();
    int t = inf.readInt(1, C[g], "t");
    ensuref(s != t, "s and t should be distinct");
    if (g == 0) {
    	ensuref(s == 2 && t == 3, "group 0");
    } else if (g == 1) {
    	ensuref(s == 1 && t == 2, "group 1");
    } else if (g == 2) {
    	ensuref(s == 3 && t == 5, "group 2");
    }
    inf.readEoln();
    inf.readEof();

    return 0;
}
