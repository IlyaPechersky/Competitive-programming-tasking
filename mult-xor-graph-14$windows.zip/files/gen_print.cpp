#include "testlib.h"
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
#define X first
#define Y second
#define mp make_pair

int main(int argc, char *argv[])
{
	registerGen(argc, argv, 1);

	int s = atoi(argv[1]);
	int t = atoi(argv[2]);
	printf("%d %d\n", s, t);

	return 0;
}

