#include "./testlib.h"
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;
typedef pair<int, int> pii;
typedef long long ll;
#define mp make_pair

const int MAX_P = (int)2e5 + 1;
const ll INF = ((ll)1 << 62) - 1;
ll s, t;

ll getAnswer(InStream &in)
{
	int n;
    n = in.readInt(1, MAX_P);
    ll v = in.readLong(1, INF);
    if (v != s) return -1;
    ll res = 0;
    for (int i = 1; i < n; i++) {
        ll u = in.readLong(1, INF);
        if (INF / u < v) return -1;
        res ^= v * u;
        v = u;
    }
    if (v != t) return -1;
    return res;
}

int main(int argc, char * argv[])
{
    registerTestlibCmd(argc, argv);

    s = inf.readInt();
    t = inf.readInt();

    ll jury = getAnswer(ans);
    ll part = getAnswer(ouf);

    if (jury == -1)
    	quitf(_fail, "Jury has incorrect answer");
    if (part == -1)
    	quitf(_wa, "Participant has incorrect answer");
    if (part < jury)
    	quitf(_fail, "Participant (%lld) has better answer than jury (%lld)", part, jury);
    if (part > jury)
    	quitf(_wa, "Jury (%lld) has better answer than participant (%lld)", jury, part);
    quitf(_ok, "OK valid solution (%lld)", jury);

    return 0;
}